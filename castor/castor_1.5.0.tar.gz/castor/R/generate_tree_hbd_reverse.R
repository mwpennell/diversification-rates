# generate a random ultrametric timetree according to the homogenous birth-death model, in backward time, based on a provided pulled speciation rate (as a function of age)
generate_tree_hbd_reverse = function(	Ntips,							# (integer) Number of tips in the tree
										age_grid			= NULL,		# either NULL, or empty, or a numeric vector of size NG, listing ages in ascending order, on which the PSR is specified. If NULL or empty, then the PSR must be a single scalar. The returned time series will be defined on an age-grid that may be finer than this grid.
										PSR					= 0,		# either a single numeric (constant PSR over time), or a numeric vector of size NG (listing PSR at each age in age_grid[]).
										splines_degree		= 1,		# integer, either 1 or 2 or 3, specifying the degree for the splines defined by PSR on the age grid.
										tip_basename		= "",		# (character) basename for tips (e.g. "tip."). 
										node_basename		= NULL,		# (character) basename for nodes (e.g. "node."). If NULL, then nodes will not have any labels.
										edge_basename		= NULL){	# (character) basename for edge (e.g. "edge."). If NULL, then edges will not have any labels.
	age0 = 0
	if(is.null(age_grid) || (length(age_grid)<=1)){
		if((!is.null(PSR)) && (length(PSR)!=1)) return(list(success = FALSE, error = sprintf("Invalid number of PSR values; since no age grid was provided, you must either provide a single (constant) PSR or none")))
		# create dummy age grid
		NG 			= 2;
		age_grid	= seq(from=0,to=1.0,length.out=NG)
		if(!is.null(PSR)) PSR = rep(PSR,times=NG);
	}else{
		NG = length(age_grid);
		if((age_grid[1]>age0) || (age_grid[NG]<age0)) return(list(success = FALSE, error = sprintf("Age grid must cover the entire requested age interval, including age0 (%g)",age0)))
		if((!is.null(PSR)) && (length(PSR)==1)) PSR = rep(PSR,times=NG);
	}
	if(!(splines_degree %in% c(0,1,2,3))) return(list(success = FALSE, error = sprintf("Invalid splines_degree (%d): Expected one of 0,1,2,3.",splines_degree)))
		
	results = generate_tree_from_PSR_CPP(age_grid, PSR, splines_degree, Ntips);
	if(!results$success) return(list(success=FALSE, error=results$error)); # something went wrong
	Ntips	= results$Ntips
	Nnodes 	= results$Nnodes
	Nedges 	= results$Nedges
	tree = list(Nnode 		= Nnodes,
				tip.label 	= paste(tip_basename, 1:Ntips, sep=""),
				node.label 	= (if(is.null(node_basename)) NULL else paste(node_basename, 1:Nnodes, sep="")),
				edge.label 	= (if(is.null(edge_basename)) NULL else paste(edge_basename, 1:Nedges, sep="")),
				edge 		= matrix(results$tree_edge,ncol=2,byrow=TRUE) + 1,
				edge.length = results$edge_length,
				root 		= results$root+1)
	class(tree) = "phylo";
	attr(tree,"order") = "none";

	return(list(success	= TRUE,
				tree	= tree));
}