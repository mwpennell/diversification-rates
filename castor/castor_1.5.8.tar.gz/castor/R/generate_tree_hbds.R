# generate a random phylogenetic tree according to a homogenous birth-death-sampling process
# the speciation, extinction and continuous (Poissonian) sampling rate can each be time-dependent, and there may be additional discrete sampling times included
# The simulation proceeds in forward time (starting from the root) until one of the stopping criteria are met, OR once all lineages are extinct.
generate_tree_hbds = function(	max_sampled_tips		= NULL, 
								max_extant_tips			= NULL,
								max_extinct_tips		= NULL,
								max_tips				= NULL, 	# integer, max number of tips of any type (extant + extinct + sampled). The simulation is halted once this number is reached.
								max_time				= NULL,
								include_extant			= FALSE,	# logical, whether to include extant non-sampled tips in the final tree
								include_extinct			= FALSE,	# logical, whether to include extinct non-sampled tips in the final tree
								as_generations			= FALSE,	# if FALSE, then edge lengths correspond to time. If TRUE, then edge lengths correspond to generations (hence if include_extant==true and include_extinct==true, all edges will have unit length).
								time_grid				= NULL,		# numeric vector listing grid times in ascending order. The time grid should generally cover the maximum possible simulation time, otherwise it will be polynomially extrapolated (according to splines_degree).
								lambda					= NULL,		# numeric vector of the same length as time_grid[], listing per-capita birth rates (speciation rates) at each time point
								mu						= NULL,		# numeric vector of the same length as time_grid[], listing per-capita death rates (extinction rates) at each time point
								rho						= NULL,		# numeric vector of the same length as time_grid[], listing per-capita sampling rates (Poissonian detection rates) at each time point
								splines_degree			= 1,		# polynomial degree of time-dependent model parameters (lambda, mu, rho) between time-grid points
								discrete_sampling_times	= NULL,		# optional numeric vector listing discrete sampling times, in ascending order
								discrete_sampling_probs	= NULL,		# optional numeric vector listing discrete sampling probabilities, corresponding to discrete_sampling_times[]
								tip_basename			= "",		# basename for tips (e.g. "tip."). 
								node_basename			= NULL,		# basename for nodes (e.g. "node."). If NULL, then nodes will not have any labels.
								edge_basename			= NULL,		# basename for edge (e.g. "edge."). If NULL, then edges will not have any labels.
								include_birth_times		= FALSE,
								include_death_times		= FALSE){
	# basic input checking
	if(is.null(max_tips) && is.null(max_sampled_tips) && is.null(max_extant_tips) && is.null(max_extinct_tips) && is.null(max_time)) return(list(success=FALSE, error="ERROR: At least one of {max_tips, max_sampled_tips, max_extant_tips, max_extinct_tips, max_time} must be non-NULL"));
	if(is.null(time_grid) || (length(time_grid)<=1)){
		if((!is.null(lambda)) && (length(lambda)!=1)) return(list(success = FALSE, error = sprintf("Invalid number of lambda values (%d); since no time grid was provided, you must either provide a single (constant) birth rate or NULL",length(lambda))))
		if((!is.null(mu)) && (length(mu)!=1)) return(list(success = FALSE, error = sprintf("Invalid number of mu values (%d); since no time grid was provided, you must either provide a single (constant) death rate or none",length(mu))))
		if((!is.null(rho)) && (length(rho)!=1)) return(list(success = FALSE, error = sprintf("Invalid number of rho values (%d); since no time grid was provided, you must either provide a single (constant) sampling rate or none",length(rho))))
		# create dummy time grid
		NG = 2;
		time_grid = seq(from=0,to=1,length.out=NG)
		if(!is.null(lambda)){
			lambda = rep(lambda,times=NG)
		}else{
			lambda = rep(0,times=NG)
		}
		if(!is.null(mu)){
			mu = rep(mu,times=NG)
		}else{
			mu = rep(0,times=NG)
		}
		if(!is.null(rho)){
			rho = rep(rho,times=NG)
		}else{
			rho = rep(0,times=NG)
		}
	}else{
		NG = length(time_grid);
		if(is.null(lambda)){
			lambda = rep(0,times=NG)
		}else if(length(lambda)==1){
			lambda = rep(lambda,times=NG)
		}else if(length(lambda)!=NG){
			return(list(success=FALSE, error=sprintf("Expected either a single birth-rate or exactly %d birth-rates (=time_grid length), but instead got %d",NG,length(lambda))))
		}
		if(is.null(mu)){
			mu = rep(0,times=NG)
		}else if(length(mu)==1){
			mu = rep(mu,times=NG)
		}else if(length(mu)!=NG){
			return(list(success=FALSE, error=sprintf("Expected either a single death-rate or exactly %d death-rates (=time_grid length), but instead got %d",NG,length(mu))))
		}
		if(is.null(rho)){
			rho = rep(0,times=NG)
		}else if(length(rho)==1){
			rho = rep(rho,times=NG)
		}else if(length(rho)!=NG){
			return(list(success=FALSE, error=sprintf("Expected either a single sampling-rate or exactly %d sampling-rates (=time_grid length), but instead got %d",NG,length(rho))))
		}
		if(any(diff(time_grid)<=0)) return(list(success = FALSE, error = sprintf("Values in time_grid must be strictly increasing")))
	}
	if(is.null(discrete_sampling_times) && (!is.null(discrete_sampling_probs))) return(list(success=FALSE, error="discrete_sampling_times is missing while discrete_sampling_probs was provided; either provide both or none"))
	if((!is.null(discrete_sampling_times)) && is.null(discrete_sampling_probs)) return(list(success=FALSE, error="discrete_sampling_probs is missing while discrete_sampling_times was provided; either provide both or none"))
	if((!is.null(discrete_sampling_times)) && (!is.null(discrete_sampling_probs))){
		if(length(discrete_sampling_times)!=length(discrete_sampling_probs)) return(list(success=FALSE, error="Number of discrete_sampling_times (%d) differs from number of discrete_sampling_probs (%d)",length(discrete_sampling_times),length(discrete_sampling_probs)))
		if(any(diff(discrete_sampling_times)<=0)) return(list(success=FALSE, error="discrete_sampling_times must be in strictly increasing order"))
		if(any(discrete_sampling_probs<0) || any(discrete_sampling_probs>1)) return(list(success=FALSE, error="discrete_sampling_probs must be true probabilities, and thus between 0 and 1"))
	}
	
	# generate tree
	results = generate_random_tree_HBDS_CPP(max_sampled_tips		= (if(is.null(max_sampled_tips)) -1 else max_sampled_tips),
											max_extant_tips			= (if(is.null(max_extant_tips)) -1 else max_extant_tips),
											max_extinct_tips		= (if(is.null(max_extinct_tips)) -1 else max_extinct_tips),
											max_tips				= (if(is.null(max_tips)) -1 else max_tips),
											max_time				= (if(is.null(max_time)) -1 else max_time),
											time_grid				= time_grid,
											birth_rates				= lambda,
											death_rates				= mu,
											sampling_rates			= rho,
											splines_degree			= splines_degree,
											discrete_sampling_times	= (if(is.null(discrete_sampling_times)) numeric() else discrete_sampling_times),
											discrete_sampling_probs	= (if(is.null(discrete_sampling_probs)) numeric() else discrete_sampling_probs),
											as_generations			= as_generations,
											include_extant			= include_extant,
											include_extinct			= include_extinct,
											include_birth_times		= include_birth_times,
											include_death_times		= include_death_times)
	if(!results$success) return(list(success=FALSE, error=results$error)); # something went wrong
	Ntips	= results$Ntips
	Nnodes 	= results$Nnodes
	Nedges 	= results$Nedges
	tree = list(Nnode 		= Nnodes,
				tip.label 	= paste(tip_basename, 1:Ntips, sep=""),
				node.label 	= (if(is.null(node_basename)) NULL else paste(node_basename, 1:Nnodes, sep="")),
				edge.label 	= (if(is.null(edge_basename)) NULL else paste(edge_basename, 1:Nedges, sep="")),
				edge 		= matrix(results$tree_edge,ncol=2,byrow=TRUE) + 1,
				edge.length = results$edge_length,
				root 		= results$root+1)
	class(tree) = "phylo";
	attr(tree,"order") = "none";
		
	return(list(success				= TRUE,
				tree				= tree,
				root_time			= results$root_time,
				final_time			= results$final_time,
				Nbirths		 		= results$Nbirths,
				Ndeaths				= results$Ndeaths,
				Nsamplings			= results$Nsamplings,
				sampled_tips		= results$sampled_tips+1,
				extant_tips			= (if(include_extant) results$extant_tips+1 else integer()),
				extinct_tips		= (if(include_extinct) results$extinct_tips+1 else integer())));
	
}